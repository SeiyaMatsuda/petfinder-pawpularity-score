from sklearn.model_selection import StratifiedKFold
import numpy as np
import pandas as pd
from collections import OrderedDict
import torch
import time
import math
import random
def fix_seed(seed):
    # random
    random.seed(seed)
    # Numpy
    np.random.seed(seed)
    # Pytorch
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True

def get_train_data(df, y, n_splits=10, regression=False):
    kf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    if regression:
        y = pd.qcut(y, q=20,labels=False)
    for n, (train_index, val_index)  in enumerate(kf.split(df, y)):
        df.loc[val_index, 'fold'] = int(n)
    df["fold"] = df["fold"].astype(np.uint8)
    return df

def init_logger(OUTPUT_DIR):
    from logging import INFO, FileHandler, Formatter, StreamHandler, getLogger
    log_file=OUTPUT_DIR / "train.log"
    logger = getLogger(__name__)
    logger.setLevel(INFO)
    handler1 = StreamHandler()
    handler1.setFormatter(Formatter("%(message)s"))
    handler2 = FileHandler(filename=log_file)
    handler2.setFormatter(Formatter("%(message)s"))
    logger.addHandler(handler1)
    logger.addHandler(handler2)
    return logger

class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count
        
def asMinutes(s):
    m = math.floor(s / 60)
    s -= m * 60
    return "%dm %ds" % (m, s)


def timeSince(since, percent):
    now = time.time()
    s = now - since
    es = s / (percent)
    rs = es - s
    return "%s (remain %s)" % (asMinutes(s), asMinutes(rs))

def fix_model_state_dict(state_dict):
    new_state_dict = OrderedDict()
    for k, v in state_dict.items():
        name = k
        if name.startswith('module.'):
            name = name[7:]  # remove 'module.' of dataparallel
        new_state_dict[name] = v
    return new_state_dict
